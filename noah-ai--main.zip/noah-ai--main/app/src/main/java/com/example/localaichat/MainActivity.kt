package com.example.localaichat

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.codeshipping.llamakotlin.LlamaModel
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private var llamaModel: LlamaModel? = null
    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private lateinit var scrollView: ScrollView
    private lateinit var tvResponse: TextView
    private lateinit var tvModelName: TextView
    private lateinit var etInput: EditText
    private lateinit var btnSend: Button
    private lateinit var btnVoiceToggle: Button
    private lateinit var btnSelectModel: Button
    private lateinit var layoutChatCard: FrameLayout

    private var isContinuousVoiceMode = false
    private val chatHistory = mutableListOf<Pair<String, String>>()

    private val PREFS_NAME = "NoahAiPrefs"
    private val KEY_MODEL_NAME = "saved_model_name"

    private val filePickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { saveAndLoadModel(it) }
    }

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
        if (isGranted) {
            startContinuousVoiceMode()
        } else {
            Toast.makeText(this, "음성 대화를 진행하려면 마이크 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
            resetVoiceButtonUi()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scrollView = findViewById(R.id.scrollView)
        tvResponse = findViewById(R.id.tvResponse)
        tvModelName = findViewById(R.id.tvModelName)
        etInput = findViewById(R.id.etInput)
        btnSend = findViewById(R.id.btnSend)
        btnVoiceToggle = findViewById(R.id.btnVoiceToggle)
        btnSelectModel = findViewById(R.id.btnSelectModel)
        layoutChatCard = findViewById(R.id.layoutChatCard)

        applyDynamicRoundedStyle()

        initSpeechRecognizer()
        textToSpeech = TextToSpeech(this, this)

        btnSelectModel.setOnClickListener {
            filePickerLauncher.launch("*/*")
        }

        btnVoiceToggle.setOnClickListener {
            isContinuousVoiceMode = !isContinuousVoiceMode
            if (isContinuousVoiceMode) {
                btnVoiceToggle.text = "대화 중..."
                updateVoiceButtonBg("#444444")
                checkMicPermissionAndStart()
            } else {
                resetVoiceButtonUi()
                stopVoiceMode()
            }
        }

        btnSend.setOnClickListener {
            val userText = etInput.text.toString().trim()
            if (userText.isNotEmpty()) {
                askAi(userText)
                etInput.text.clear()
            }
        }

        checkAndLoadSavedModel()
    }

    private fun applyDynamicRoundedStyle() {
        fun dpToPx(dp: Int): Float = dp * resources.displayMetrics.density

        val cardBg = GradientDrawable().apply {
            setColor(Color.parseColor("#1A1A1A"))
            cornerRadius = dpToPx(16)
            setStroke(dpToPx(1).toInt(), Color.parseColor("#2A2A2A"))
        }
        layoutChatCard.background = cardBg

        val darkButtonBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2A2A2A"))
            cornerRadius = dpToPx(12)
        }
        btnSelectModel.background = darkButtonBg
        btnVoiceToggle.background = darkButtonBg
        etInput.background = darkButtonBg

        val sendButtonBg = GradientDrawable().apply {
            setColor(Color.parseColor("#E0E0E0"))
            cornerRadius = dpToPx(12)
        }
        btnSend.background = sendButtonBg
    }

    private fun updateVoiceButtonBg(colorHex: String) {
        val dpToPx = 12 * resources.displayMetrics.density
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor(colorHex))
            cornerRadius = dpToPx
        }
        btnVoiceToggle.background = bg
    }

    private fun resetVoiceButtonUi() {
        isContinuousVoiceMode = false
        btnVoiceToggle.text = "음성 모드"
        updateVoiceButtonBg("#2A2A2A")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.setLanguage(Locale.KOREAN)

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    if (isContinuousVoiceMode) {
                        runOnUiThread {
                            startVoiceRecognition()
                        }
                    }
                }

                override fun onError(utteranceId: String?) {}
            })
        }
    }

    private fun checkMicPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startContinuousVoiceMode()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startContinuousVoiceMode() {
        if (llamaModel == null) {
            Toast.makeText(this, "먼저 상단에서 AI 모델(.gguf)을 선택해 주십시오.", Toast.LENGTH_SHORT).show()
            resetVoiceButtonUi()
            return
        }
        startVoiceRecognition()
    }

    private fun stopVoiceMode() {
        textToSpeech?.stop()
        speechRecognizer?.stopListening()
        Toast.makeText(this, "음성 대화 모드를 종료합니다.", Toast.LENGTH_SHORT).show()
    }

    private fun initSpeechRecognizer() {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}

                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val userText = matches?.firstOrNull()

                        if (!userText.isNullOrEmpty()) {
                            etInput.setText(userText)
                            askAi(userText)
                        } else if (isContinuousVoiceMode) {
                            startVoiceRecognition()
                        }
                    }

                    override fun onError(error: Int) {
                        Log.e("STT", "Error code: $error")
                        if (isContinuousVoiceMode) {
                            runOnUiThread { startVoiceRecognition() }
                        }
                    }

                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e("STT", "SpeechRecognizer init failed", e)
        }
    }

    private fun startVoiceRecognition() {
        if (!isContinuousVoiceMode || speechRecognizer == null) return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
        }
        speechRecognizer?.startListening(intent)
    }

    private fun checkAndLoadSavedModel() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedModelName = prefs.getString(KEY_MODEL_NAME, null)
        val modelFile = File(filesDir, "persistent_model.gguf")

        if (savedModelName != null && modelFile.exists()) {
            tvModelName.text = savedModelName
            tvResponse.text = "이전에 선택한 모델($savedModelName)을 불러오는 중입니다..."
            loadModelInternal(modelFile, savedModelName)
        } else {
            tvModelName.text = "선택된 모델 없음"
            tvResponse.text = "상단에서 .gguf 모델을 선택하시면 자동으로 저장되어 다음에도 유지됩니다."
        }
    }

    private fun saveAndLoadModel(uri: Uri) {
        val originalName = getFileNameFromUri(uri) ?: "model.gguf"
        tvResponse.text = "새로운 AI 모델 파일($originalName)을 저장 및 로드 중입니다..."

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val persistentFile = File(filesDir, "persistent_model.gguf")
                contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(persistentFile).use { output ->
                        input.copyTo(output)
                    }
                }

                getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                    .putString(KEY_MODEL_NAME, originalName)
                    .apply()

                withContext(Dispatchers.Main) {
                    tvModelName.text = originalName
                }

                loadModelInternal(persistentFile, originalName)
            } catch (e: Exception) {
                Log.e("LlamaApp", "Model save error", e)
                withContext(Dispatchers.Main) {
                    tvResponse.text = "모델 파일 저장 실패: ${e.message}"
                }
            }
        }
    }

    private fun loadModelInternal(file: File, displayName: String) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                llamaModel?.close()
                llamaModel = null

                llamaModel = LlamaModel.load(file.absolutePath) {
                    contextSize = 4096 
                    threads = 2
                    batchSize = 128
                    temperature = 0.7f
                    topP = 0.9f
                }

                withContext(Dispatchers.Main) {
                    tvModelName.text = displayName
                    tvResponse.text = "AI 비서 준비 완료 ($displayName).\n메시지를 입력하거나 [음성 모드]를 시작하십시오."
                    chatHistory.clear()
                }
            } catch (e: Exception) {
                Log.e("LlamaApp", "Model load error", e)
                withContext(Dispatchers.Main) {
                    tvResponse.text = "모델 불러오기 실패: ${e.message}"
                }
            }
        }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var name: String? = null
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && nameIndex != -1) {
                name = cursor.getString(nameIndex)
            }
        }
        return name
    }
    
    private fun buildPromptWithHistory(newPrompt: String): String {
        val sb = StringBuilder()
        sb.append("System: 너는 한국어 AI 비서 'NOAH(노아)'야. 어색한 번역투 없이 아주 자연스럽고 정중한 한국어로 답변해줘. 이모지는 절대 절대 사용하지마.\n\n")

        val recentHistory = chatHistory.takeLast(10)
        for ((user, assistant) in recentHistory) {
            sb.append("User: $user\n")
            sb.append("Assistant: $assistant\n\n")
        }

        sb.append("User: $newPrompt\n")
        sb.append("Assistant:")

        return sb.toString()
    }

    private fun askAi(userPrompt: String) {
        val model = llamaModel
        if (model == null) {
            Toast.makeText(this, "먼저 상단에서 AI 모델(.gguf)을 선택해 주십시오.", Toast.LENGTH_SHORT).show()
            return
        }

        textToSpeech?.stop()

        if (chatHistory.isEmpty() && (tvResponse.text.contains("준비 완료") || tvResponse.text.contains("선택하시면"))) {
            tvResponse.text = ""
        }

        val currentText = tvResponse.text.toString()
        val formattedUserLabel = if (currentText.isEmpty()) "나: $userPrompt\nNOAH: " else "\n\n나: $userPrompt\nNOAH: "
        tvResponse.append(formattedUserLabel)
        scrollToBottom()

        val fullPrompt = buildPromptWithHistory(userPrompt)

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                // 1. 백그라운드에서 전체 답변을 완성될 때까지 연산 (UI 튕김 완벽 방지)
                val fullResponse = model.generate(fullPrompt)

                // 2. 대화 기록 저장
                if (fullResponse.isNotEmpty()) {
                    chatHistory.add(Pair(userPrompt, fullResponse))
                }

                // 3. 메인 스레드에서 화면 업데이트 및 음성 출력
                withContext(Dispatchers.Main) {
                    tvResponse.append(fullResponse)
                    tvResponse.post { scrollToBottom() }

                    if (fullResponse.isNotEmpty()) {
                        speakOut(fullResponse)
                    }
                }
            } catch (e: Exception) {
                Log.e("LlamaApp", "Generation error", e)
                withContext(Dispatchers.Main) {
                    tvResponse.append("\n[답변 생성 실패: ${e.message}]")
                }
            }
        }
    }

    private fun scrollToBottom() {
        scrollView.post {
            scrollView.fullScroll(ScrollView.FOCUS_DOWN)
        }
    }

    private fun speakOut(text: String) {
        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "AI_RESPONSE_DONE")
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "AI_RESPONSE_DONE")
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        llamaModel?.close()
        llamaModel = null
    }
}
